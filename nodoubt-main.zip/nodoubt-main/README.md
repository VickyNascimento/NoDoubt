# NoDoubt

Projeto Final do Curso Técnico Integrado de Desenvolvimento de Sistemas - Colégio Pedro II - Campus Duque de Caxias

**Integrantes:**
 - Vicky do nascimento wingler
 - JÚlia Sena da Costa
 - Caio Felipe de Oliveira Martins
 - VitÓria Maria Sousa Pinto da Costa

 ## Descrição do Projeto

  O projeto consiste em uma rede social bem aberta ao estilo fórum para estudantes  de todos os níveis de escolaridade postarem suas dúvidas  sobre conteúdos diversos ou até mesmo de suas áreas de estudos, e outros usuários poderão responder essas dúvidas. E com o auxílio de método de votação popular pelos usuário , as respostas mais votadas serão tidas como corretas. Dessa forma, garatindo maior confiabilidade nas respostas e tornando assim a educação algo mais democrático.
## Documentação

- [Manual do Usuário](manual.md)
- [Requisitos](requisitos.md)
- [Casos de Uso](casos-de-uso.md)
- [Apresentação](Apresentação.pdf)

**Modelagem do Banco de Dados**

![banco de dados](https://user-images.githubusercontent.com/55743181/146242297-87547968-809c-4e98-9317-e1e781f0e2c7.jpeg)

## informações do PHP e PHPMYADIMIN

- Servidor: 127.0.0.1 via TCP/IP
- Tipo de servidor: MariaDB
- Versão do servidor: 10.4.21-MariaDB - mariadb.org binary distribution
- versão do PHP: 7.3.31
- Informação da versão: 5.1.1 (atualizada)

## Instruções para usuarios de teste

- Email do usuario padrão de teste
testuser@gmail.com
- Senha do usuario padrão de teste
1425368

- Email do usuario adiminstrador de teste
nodoubttt0@gmail.com
- Senha do usuario adiminstrador de teste
36612206
